function handleClick(el) {
  var clickedElement = el;
  var src = clickedElement.src;
  var display = document.getElementById('display');
  display.src = src;
}

